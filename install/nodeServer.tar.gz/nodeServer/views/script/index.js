function clickTdEvent(tdobj) {
	var tdHtml = tdobj.innerHTML;
	var inputBox = $("input[name=searchWord]").val();
	if (inputBox.indexOf(tdHtml) == -1) {
		$("input[name=searchWord]").val(inputBox + ' ' + tdHtml);
	} else {
		inputBox = inputBox.replace(" " + tdHtml, "");
		$("input[name=searchWord]").val(inputBox);
	}

	console.log(tdHtml);
}

function clickTimeStageEvent() {
	if ($("#timeStepContent").attr("stat") == "hide") {
		$("#timeStepContent").show();
		$("#timeStepContent").attr("stat", "show");
	} else {
		$("#timeStepContent").hide();
		$("#timeStepContent").attr("stat", "hide");
	}
}

function clickNewsDataEvent() {
	//$("#timeStepContent").show();
	var id = '#newsDataContent';
	if ($(id).attr("stat") == "hide") {
		$(id).show();
		$(id).attr("stat", "show");

		$.ajax({
			//The URL to process the request
			url: '/news',
			//The type of request, also known as the "method" in HTML forms
			//Can be 'GET' or 'POST'
			type: 'POST',
			//Any post-data/get-data parameters
			//This is optional
			dataType: "json",
			data: {
				'word': "a",
			},

			//The response from the server
			success: function(data) {
				//Static
				//console.log(data);
				console.log(data.newsData,length/5);
				for(k=0;k<data.newsData.length;k++){
					var newsTable = '';
					for(i=0;i<5;i++){
						newsTable+="<tr>";
						for(j=0;j<3;j++){
							newsTable+="<td>"+data.newsData[k][i][j]+"</td>";
						}
						newTable="</tr>";
					}
			  if(k==0){
					$("#news5month").html(newsTable);
			  }

				if(k==1)
						$("#news6month").html(newsTable);
					if(k==2)
						$("#news7month").html(newsTable);
					if(k==3)
						$("#news8month").html(newsTable);
					if(k==4)
						$("#news9month").html(newsTable);
				}
			},

			error: function(xhr, status, error) {
				console.log("error" + xhr.responseText);
				$('#loading').modal('hide')
			},
			beforeSend: function() {

			},
			complete: function() {

			}
		});


		/*$.getJSON("/refinednews/result-cvb-05.txt.refined",function(json){
			var newsTable = '';
			for(i=0;i<5;i++){
				newsTable+="<tr>";
				for(j=0;j<3;j++){
					newsTable+="<td>"+json[i][j]+"</td>";
				}
				newTable="</tr>";
			}
			$("#news5month").html(newsTable);
    });
		$.getJSON("/refinednews/result-cvb-06.txt.refined",function(json){
			var newsTable = '';
			for(i=0;i<5;i++){
				newsTable+="<tr>";
				for(j=0;j<3;j++){
					newsTable+="<td>"+json[i][j]+"</td>";
				}
				newTable="</tr>";
			}
			$("#news6month").html(newsTable);
    });
		$.getJSON("/refinednews/result-cvb-07.txt.refined",function(json){
			var newsTable = '';
			for(i=0;i<5;i++){
				newsTable+="<tr>";
				for(j=0;j<3;j++){
					newsTable+="<td>"+json[i][j]+"</td>";
				}
				newTable="</tr>";
			}
			$("#news7month").html(newsTable);
    });
		$.getJSON("/refinednews/result-cvb-08.txt.refined",function(json){
			var newsTable = '';
			for(i=0;i<5;i++){
				newsTable+="<tr>";
				for(j=0;j<3;j++){
					newsTable+="<td>"+json[i][j]+"</td>";
				}
				newTable="</tr>";
			}
			$("#news8month").html(newsTable);
    });
		$.getJSON("/refinednews/result-cvb-09.txt.refined",function(json){
			var newsTable = '';
			for(i=0;i<5;i++){
				newsTable+="<tr>";
				for(j=0;j<3;j++){
					newsTable+="<td>"+json[i][j]+"</td>";
				}
				newTable="</tr>";
			}
			$("#news9month").html(newsTable);
    });*/
	} else {
		$(id).hide();
		$(id).attr("stat", "hide");
	}
}

function replaceAll(str, searchStr, replaceStr) {
	return str.split(searchStr).join(replaceStr);
}

$(document).ready(function() {
	document.getElementById("healthData").checked = true;
	$("#timeStepContent").hide();
	$("#newsDataContent").hide();

	function getDocLinkList(resdata) {
		console.log(resdata);
		var promiseList = [];
		if (resdata != undefined) {
			for (i = 0; i < resdata.length; i++) {
				promiseList.push(getDocLink(resdata[i].ID));
			}
			var linkList = "";
			$.when.apply(this, promiseList).done(function() {
				$.each(arguments, function(i, data) {
					console.log(data); //data is the value returned by each of the ajax requests
					console.log(i);
					linkList += '<tr> \n';
					linkList += '<td>' + resdata[i].ID + '</td>\n';
					linkList += '<td>' + data[0].outputData[0].articleInfo.deeplink + '</td>\n';
					linkList += '</tr>\n';
				});
				console.log(linkList);
				$("#linkTable").html(linkList);
			});
		}
	}

	/*$.ajax({
		//The URL to process the request
		url: '/news',
		//The type of request, also known as the "method" in HTML forms
		//Can be 'GET' or 'POST'
		type: 'POST',
		//Any post-data/get-data parameters
		//This is optional
		dataType: "json",
		data: {
			'word': "a",
		},

		//The response from the server
		success: function(data) {
			//Static
			var newsTable = '';
			newsTable += '<tr><td>연금</td><td>소득</td><td>재정</td><td>정책</td></tr>';
			newsTable += '<tr><td>아이폰</td><td>유출</td><td>페이스북</td><td>성폭행</td></tr>';
			newsTable += '<tr><td>혐의</td><td>경찰</td><td>범죄</td><td></td></tr>';
			newsTable += '<tr><td>공무원</td><td>경찰</td><td>개혁</td><td>퇴직</td></tr>';
			newsTable += '<tr><td>연인살해</td><td>택시</td><td>경찰</td></tr>';
			newsTable += '<tr><td>고양이</td><td>사망</td><td>스마트폰</td></tr>';
			newsTable += '<tr><td>환자</td><td>메르스</td><td>감염</td><td>호흡기</td></tr>';
			$("#news5month").html(newsTable);

			newsTable = '<tr><td>아이폰보험</td></tr>';
			newsTable += '<tr><td>메르스</td><td>환자</td><td>감염</td><td>호흡기</td><td>중동</td><td></td></tr>';
			newsTable += '<tr><td>표절</td><td>요리</td><td>논란</td></tr>';
			newsTable += '<tr><td>혐의</td><td>범죄</td><td>비리</td></tr>';
			newsTable += '<tr><td>삼성물산</td><td>합병</td><td>엘리엇</td><td>제일모직</td></tr>';
			newsTable += '<tr><td>게임</td><td>콘텐츠</td><td>서비스</td><td>혁신</td></tr>';
			$("#news6month").html(newsTable);

			newsTable = '<tr><td>아이폰</td><td>갤럭시</td></tr>';
			newsTable += '<tr><td>그리스</td><td>금융</td><td>은행</td></tr>';
			newsTable += '<tr><td>태풍</td><td>해상</td><td>기상청</td></tr>';
			newsTable += '<tr><td>환자</td><td>병원</td><td>메르스</td><td>질환</td></tr>';
			newsTable += '<tr><td>울산</td><td>공장</td><td>사고</td><td>한화케미칼</td></tr>';
			newsTable += '<tr><td>경찰</td><td>혐의</td><td>마을피해자</td></tr>';

			$("#news7month").html(newsTable);

			newsTable = '<tr><td>롯데그룹</td><td>회장</td><td>기업</td><td>분쟁</td><td>출자</td></tr>';
			newsTable += '<tr><td>정부</td><td>노동</td><td>개혁</td><td>임금</td><td>고용</td></tr>';
			newsTable += '<tr><td>서울</td><td>학교</td><td>교사</td><td>교육청</td></tr>';
			newsTable += '<tr><td>경찰</td><td>여성용의자</td><td></td></tr>';
			newsTable += '<tr><td>분양</td><td>아파트</td><td>도시</td></tr>';
			newsTable += '<tr><td>북한</td><td>지뢰</td><td>도발</td><td></td></tr>';
			newsTable += '<tr><td>혐의</td><td>경찰</td><td>병원</td><td>의료</td><td>폭행</td></tr>';
			newsTable += '<tr><td>중국</td><td>베이징</td><td>열병식</td><td>전승절</td></tr>';
			newsTable += '<tr><td>도발</td><td>북한</td><td>남북</td><td>고위급</td><td>확성기</td></tr>';
			newsTable += '<tr><td>남북</td><td>평화</td><td>역사</td><td>외교</td></tr>';
			$("#news8month").html(newsTable);

			newsTable = '<tr><td>애플</td><td>스마트폰</td><td>브랜드</td><td>아이폰</td></tr>';
			newsTable += '<tr><td>농구</td><td>도박</td></tr>';
			newsTable += '<tr><td>아파트</td><td>주거</td><td>환경</td></tr>';
			newsTable += '<tr><td>난민</td><td>국가</td><td>시리아</td></tr>';
			newsTable += '<tr><td>사고</td><td>해경</td><td>해양</td><td>전복</td></tr>';
			newsTable += '<tr><td>경찰</td><td>노조</td><td>파업</td><td>임금</td></tr>';
			newsTable += '<tr><td>대통령</td><td>정상회담</td><td>열병식</td></tr>';
			$("#news9month").html(newsTable);
			//Dynamic

			console.log(data);
			console.log(makeNewsTable(data.newsData[0].keywords));
			$("#news5month").html(makeNewsTable(data.newsData[0].keywords));
			$("#news6month").html(makeNewsTable(data.newsData[1].keywords));
			$("#news7month").html(makeNewsTable(data.newsData[2].keywords));
			$("#news8month").html(makeNewsTable(data.newsData[3].keywords));
			$("#news9month").html(makeNewsTable(data.newsData[4].keywords));

		},

		error: function(xhr, status, error) {
			console.log("error" + xhr.responseText);
			$('#loading').modal('hide')
		},
		beforeSend: function() {

		},
		complete: function() {

		}
	});*/

	$("input[name=groupName]").change(function() {
		console.log($(this).val());
		$("#Paper0910Title").html($(this).val() + " Paper_0910");
		$("#Paper1112Title").html($(this).val() + " Paper_1112");
		$("#Paper1314Title").html($(this).val() + " Paper_1314");
		$("#Patent0910Title").html($(this).val() + " Patent_0910");
		$("#Patent1112Title").html($(this).val() + " Patent_1112");
		$("#Patent1314Title").html($(this).val() + " Patent_1314");
		$("#Report0910Title").html($(this).val() + " Report_0910");
		$("#Report1112Title").html($(this).val() + " Report_1112");
		$("#Report1314Title").html($(this).val() + " Report_1314");
		$("#wordTable").html("");
		$("#Paper0910Table").html("");
		$("#Paper1112Table").html("");
		$("#Paper1314Table").html("");
		$("#Patent0910Table").html("");
		$("#Patent1112Table").html("");
		$("#Patent1314Table").html("");
		$("#Report0910Table").html("");
		$("#Report1112Table").html("");
		$("#Report1314Table").html("");
	});

	$("#searchButton").click(function() {

		searchWord();
	});

	$("#inputBox").keypress(function(e) {
		if (e.which == 13) { /* 13 == enter key@ascii */
			searchWord();
		}
	});

	function searchWord() {
		$('#loading').modal();
		clearTable();
		if ($("input[name=groupName]:checked").val() == undefined) {
			alert("check group");
			return 0;
		}
		var url = "http://165.194.35.221:3000/users";
		var word = $("input[name=searchWord]").val();
		var groupName = $("input[name=groupName]:checked").val();
		var docIndex = $("input[name=searchDocIndex]").val();



		$.ajax({
			//The URL to process the request
			url: '/search',
			//The type of request, also known as the "method" in HTML forms
			//Can be 'GET' or 'POST'
			type: 'POST',
			//Any post-data/get-data parameters
			//This is optional
			dataType: "json",
			data: {
				'word': word,
				'groupName': groupName,
				'docIndex': docIndex
			},

			//The response from the server
			success: function(data) {
				//You can use any jQuery/JavaScript here!!!
				//console.log(data);
				if (data.resData == undefined && data.resDataPaper0910 == undefined && data.resDataPaper1112 == undefined && data.resDataPaper1314 == undefined) {
					alert("no Data");
				} else {
					getDocLinkList(data.resDataIndexD);

					//console.log(data.resDataCluster);

					if (data.resDataCluster != undefined) {
						var ClusterList = "";
						for (i = 0; i < data.resDataCluster.length; i++) {
							ClusterList += '<div class="col-lg-2">컨셉' + (i + 1) + '<table class="table table-border" data-toggle="table" data-cache="false" data-height="100px">';
							ClusterList += '<thead style="background-color:#eeeeee"><tr><th data-field="KeyWord">키워드</th>';
							//ClusterList += '<th data-field="score">score</th>
							ClusterList += '</tr></thead><tbody>';
							for (j = 0; j < data.resDataCluster[i].length; j++) {
								ClusterList += '<tr> \n';
								ClusterList += '<td class="addSearchKeyword" onclick="javascript:clickTdEvent(this)" >' + data.resDataCluster[i][j].keyword + '</td> \n';
								//ClusterList += '<td>' + data.resDataCluster[i][j].similarity + '</td> \n';
								ClusterList += '</tr>\n';
							}
							ClusterList += '</tbody></table></div>';
						}



						$("#wordTable").html(ClusterList);
					}

					var paperDocList = getPaperList(word);
					if (paperDocList != undefined) {
						paperDocList.done(function(data1) {
							var docNumberList = "";
							for (i = 0; i < data1.outputData.length; i++) {
								docNumberList += '<tr> \n';
								docNumberList += '<td width="150px" nowrap><a href="#" onclick="asd();">' + data1.outputData[i]["@kistiID"] + '</a></td> \n';
								var hilightedAbstract = data1.outputData[i].articleInfo.abstractInfo[0];
								for (k = 0; k < data.resDataCluster.length; k++) {
									for (m = 0; m < data.resDataCluster[k].length; m++) {
										hilightedAbstract = replaceAll(hilightedAbstract, data.resDataCluster[k][m].keyword, '<span style="background-color:#CEECF5">' + data.resDataCluster[k][m].keyword + '</span>');
									}
								}
								var searchWordList = $("input[name=searchWord]").val().split(" ");
								for (k = 0; k < searchWordList.length; k++) {
									hilightedAbstract = replaceAll(hilightedAbstract, searchWordList[k], '<span style="background-color:yellow">' + searchWordList[k] + '</span>');
								}
								docNumberList += '<td ><a href="' + data1.outputData[i].articleInfo.deeplink + '" target="_blank">' + data1.outputData[i].articleInfo.articleTitleInfo[0];
								docNumberList += '<a href="javascript:void(0)" onclick=this.nextSibling.style.display=(this.nextSibling.style.display=="none")?"block":"none";>';
								docNumberList += '<font color=blue> <u>[초록]</u></font>';
								docNumberList += '</a><DIV style="display:none"> ' + hilightedAbstract + '</DIV></td> \n';
								docNumberList += '<td width="200px" nowrap>' + data1.outputData[i].journalInfo.publisher + '</td> \n';
								docNumberList += '<td width="200px" nowrap>' + data1.outputData[i].journalInfo.journalTitleInfo[0] + '</td> \n';
								docNumberList += '</tr>\n';
							}
							$("#docNumberPaperTable").html(docNumberList);
						});
					}

					var paperDocList = getPatentList(word);
					if (paperDocList != undefined) {
						paperDocList.done(function(data1) {

							var docNumberList = "";
							for (i = 0; i < data1.outputData.length; i++) {
								docNumberList += '<tr> \n';
								docNumberList += '<td width="150px" nowrap><a href="#" onclick="asd();">' + data1.outputData[i]["@kistiID"] + '</a></td> \n';
								var hilightedAbstract = data1.outputData[i].patentInfo.abstract;
								for (k = 0; k < data.resDataCluster.length; k++) {
									for (m = 0; m < data.resDataCluster[k].length; m++) {
										hilightedAbstract = replaceAll(hilightedAbstract,
											data.resDataCluster[k][m].keyword,
											'<span style="background-color:#CEECF5">' + data.resDataCluster[k][m].keyword + '</span>');
									}
								}
								var searchWordList = $("input[name=searchWord]").val().split(" ");
								for (k = 0; k < searchWordList.length; k++) {
									hilightedAbstract = replaceAll(hilightedAbstract, searchWordList[k], '<span style="background-color:yellow">' + searchWordList[k] + '</span>');
								}
								docNumberList += '<td ><a href="' + data1.outputData[i].patentInfo.deepLink + '" target="_blank">' + data1.outputData[i].patentInfo.patentTitle;
								docNumberList += '<a href="javascript:void(0)" onclick=this.nextSibling.style.display=(this.nextSibling.style.display=="none")?"block":"none";>';
								docNumberList += '<font color=blue> <u>[초록]</u></font>' + '</a><DIV style="display:none"> ';
								docNumberList += hilightedAbstract + '</DIV></td> \n';

								if (data1.outputData[i].patentInfo.applicantsInfo.lengh > 1) {
									docNumberList += '<td width="200px" nowrap>' + data1.outputData[i].patentInfo.applicantsInfo[0] + '</td> \n';
								} else {
									docNumberList += '<td width="200px" nowrap>' + data1.outputData[i].patentInfo.applicantsInfo + '</td> \n';
								}

								docNumberList += '</tr>\n';
							}
							$("#docNumberPatentTable").html(docNumberList);
						});
					}

					var paperDocList = getReportList(word);
					if (paperDocList != undefined) {
						paperDocList.done(function(data1) {

							var docNumberList = "";
							for (i = 0; i < data1.outputData.length; i++) {
								docNumberList += '<tr> \n';
								docNumberList += '<td width="150px" nowrap><a href="#" onclick="asd();">' + data1.outputData[i]["@kistiID"] + '</a></td> \n';
								var hilightedAbstract = data1.outputData[i].reportInfo.abstractInfo[0];
								for (k = 0; k < data.resDataCluster.length; k++) {
									for (m = 0; m < data.resDataCluster[k].length; m++) {
										hilightedAbstract = replaceAll(hilightedAbstract,
											data.resDataCluster[k][m].keyword,
											'<span style="background-color:#CEECF5">' + data.resDataCluster[k][m].keyword + '</span>');
									}
								}
								var searchWordList = $("input[name=searchWord]").val().split(" ");
								for (k = 0; k < searchWordList.length; k++) {
									hilightedAbstract = replaceAll(hilightedAbstract, searchWordList[k], '<span style="background-color:yellow">' + searchWordList[k] + '</span>');
								}
								docNumberList += '<td ><a href="' + data1.outputData[i].reportInfo.deepLink + '" target="_blank">' + data1.outputData[i].reportInfo.reportTitleInfo;
								docNumberList += '<a href="javascript:void(0)" onclick=this.nextSibling.style.display=(this.nextSibling.style.display=="none")?"block":"none";>';
								docNumberList += '<font color=blue> <u>[초록]</u></font>' + '</a><DIV style="display:none"> ';
								docNumberList += hilightedAbstract + '</DIV></td> \n';
								docNumberList += '<td width="200px" nowrap>' + data1.outputData[i].reportInfo.authorInfo + '</td> \n';
								docNumberList += '</tr>\n';
							}
							$("#docNumberReportTable").html(docNumberList);

						});
					}


					if (data.resPaperData != undefined) {
						var paperTimeAnalysisTable = "";
						paperTimeAnalysisTable = makeTimeAnalysisTable(data.resPaperData);
						$("#paperTimeAnalysis").html(paperTimeAnalysisTable);

					}
					if (data.resPatentData != undefined) {
						var patentTimeAnalysisTable = "";
						patentTimeAnalysisTable = makeTimeAnalysisTable(data.resPatentData);
						$("#patentTimeAnalysis").html(patentTimeAnalysisTable);
					}
					if (data.resReportData != undefined) {
						var reportTimeAnalysisTable = "";
						reportTimeAnalysisTable = makeTimeAnalysisTable(data.resReportData);
						$("#reportTimeAnalysis").html(reportTimeAnalysisTable);
					}


					if (data.resStepData != undefined) {
						var stepAnalysisTable = "";
						stepAnalysisTable = makeTimeAnalysisTable(data.resStepData);
						$("#stepAnalysisTable").html(stepAnalysisTable);
					}
					$("#timeStepContent").hide();

					$('#loading').modal('hide');
				}
			},

			error: function(xhr, status, error) {
				console.log("error" + xhr.responseText);
				$('#loading').modal('hide')
			},
			beforeSend: function() {

			},
			complete: function() {

			}
		});

		console.log(docIndex);
		console.log(groupName);
		console.log(word);
	}
});

function clearTable() {
	$("#wordTable").html("");
	$("#Paper0910Table").html("");
	$("#Paper1112Table").html("");
	$("#Paper1314Table").html("");
	$("#Report0910Table").html("");
	$("#Report1112Table").html("");
	$("#Report1314Table").html("");
	$("#Patent0910Table").html("");
	$("#Patent1112Table").html("");
	$("#Patent1314Table").html("");
	$("#paperTimeAnalysis").html("");
	$("#patentTimeAnalysis").html("");
	$("#reportTimeAnalysis").html("");
	$("#linkTable").html("");
}
var getDocLink = function(docName) {
	var url = 'https://openapi.ndsl.kr/itemsearch.do?keyValue=00000000&target=ARTI&searchField=BI&displayCount=10&startPosition=1&sortby=pubyear&returnType=json&responseGroup=simple&query=' + docName + '&callback=?';
	return $.get(url, {
		count: 5
	}, null, 'jsonp');
}

var getPaperList = function(word) {
	var url = 'https://openapi.ndsl.kr/itemsearch.do?keyValue=00000000&target=JAKO&searchField=BI&displayCount=10&startPosition=1&sortby=pubyear&returnType=json&responseGroup=simple&query=' + word + '&callback=?';
	return $.get(url, {
		count: 5
	}, null, 'jsonp');
}
var getPatentList = function(word) {
	var url = 'https://openapi.ndsl.kr/itemsearch.do?keyValue=00000000&target=PATENT&searchField=BI&displayCount=10&startPosition=1&sortby=pubyear&returnType=json&responseGroup=simple&query=' + word + '&callback=?';
	return $.get(url, {
		count: 5
	}, null, 'jsonp');
}
var getReportList = function(word) {
	var url = 'https://openapi.ndsl.kr/itemsearch.do?keyValue=00000000&target=REPORT&searchField=BI&displayCount=10&startPosition=1&sortby=pubyear&returnType=json&responseGroup=simple&query=' + word + '&callback=?';
	return $.get(url, {
		count: 5
	}, null, 'jsonp');
}

function makeNewsTable(keywords) {
	var newsTable = "";

	for (i = 0; i < 5; i++) {
		newsTable += '<tr>';
		newsTable += '<td>' + keywords[i] + '</td>';
		newsTable += '</tr>';
	}
	return newsTable;
}

function makeTimeAnalysisTable(docData) {
	var TimeAnalysisTable = "";
	for (i = 0; i < docData.length; i++) {
		//console.log(docData[i][0].keywords);
		/////////////////////////////
		for (j = 0; j < docData[i].length; j++) {


			TimeAnalysisTable += '<tr>';
			//for(k=0;k<data.Data[i][j].keywords.length;k++){

			//console.log(data.Data[i][0][j].keywords);
			if (docData[i][j].id == 3 || docData[i][j].id == 2) {
				if (docData[i].length == 1) {
					TimeAnalysisTable += '<td style="border-left: 3px solid;border-top: 3px solid;border-bottom: 3px solid;">' + docData[i][j].keywords[0] + '</td>';
					TimeAnalysisTable += '<td style="border-top: 3px solid;border-bottom: 3px solid;">' + docData[i][j].keywords[1] + '</td>';
					TimeAnalysisTable += '<td style="border-right: 3px solid;border-top: 3px solid;border-bottom: 3px solid;">' + docData[i][j].keywords[2] + '</td>';
					break;
				}
				if (j == 0) {
					//시작
					TimeAnalysisTable += '<td style="border-left: 3px solid;border-top: 3px solid;">' + docData[i][j].keywords[0] + '</td>';
					TimeAnalysisTable += '<td style="border-top: 3px solid;">' + docData[i][j].keywords[1] + '</td>';
					TimeAnalysisTable += '<td style="border-right: 3px solid;border-top: 3px solid;">' + docData[i][j].keywords[2] + '</td>';
				} else if (j == docData[i].length - 1) {
					//끝
					TimeAnalysisTable += '<td style="border-left: 3px solid;border-bottom: 3px solid;">' + docData[i][j].keywords[0] + '</td>';
					TimeAnalysisTable += '<td style="border-bottom: 3px solid;">' + docData[i][j].keywords[1] + '</td>';
					TimeAnalysisTable += '<td style="border-right: 3px solid;border-bottom: 3px solid;">' + docData[i][j].keywords[2] + '</td>';


				} else {
					//중간
					TimeAnalysisTable += '<td style="border-left: 3px solid;">' + docData[i][j].keywords[0] + '</td>';
					TimeAnalysisTable += '<td >' + docData[i][j].keywords[1] + '</td>';
					TimeAnalysisTable += '<td style="border-right: 3px solid;">' + docData[i][j].keywords[2] + '</td>';
				}

			} else {
				TimeAnalysisTable += '<td>' + docData[i][j].keywords[0] + '</td>';
				TimeAnalysisTable += '<td>' + docData[i][j].keywords[1] + '</td>';
				TimeAnalysisTable += '<td>' + docData[i][j].keywords[2] + '</td>';
			}
			//}
			TimeAnalysisTable += '</tr>';
		}

	}
	return TimeAnalysisTable;
}

function timeAnalysis(word, groupName) {

	$.ajax({
		//The URL to process the request
		url: '/byTime',
		//The type of request, also known as the "method" in HTML forms
		//Can be 'GET' or 'POST'
		type: 'POST',
		//Any post-data/get-data parameters
		//This is optional
		dataType: "json",

		data: {
			'word': word,
			'groupName': groupName,
		},
		success: function(data) {
			console.log("시계열분석");
			console.log(data);
			if (data.paperData != undefined) {
				var paperTimeAnalysisTable = "";
				paperTimeAnalysisTable = makeTimeAnalysisTable(data.paperData);
				$("#paperTimeAnalysis").html(paperTimeAnalysisTable);

			}
			if (data.patentData != undefined) {
				var patentTimeAnalysisTable = "";
				patentTimeAnalysisTable = makeTimeAnalysisTable(data.patentData);
				$("#patentTimeAnalysis").html(patentTimeAnalysisTable);
			}
			if (data.reportData != undefined) {
				var reportTimeAnalysisTable = "";
				reportTimeAnalysisTable = makeTimeAnalysisTable(data.reportData);
				$("#reportTimeAnalysis").html(reportTimeAnalysisTable);
			}


			if (data.stepData != undefined) {
				var stepAnalysisTable = "";
				stepAnalysisTable = makeTimeAnalysisTable(data.stepData);
				$("#stepAnalysisTable").html(stepAnalysisTable);
			}
			$("#timeStepContent").hide();



		},

		error: function(xhr, status, error) {
			console.log("error" + xhr.responseText);
			$('#loading').modal('hide')
		},
		beforeSend: function() {
			//$('#loading').modal();
		},
		complete: function() {
			//$('#loading').modal('hide');
		}
	});
}



$(document).ajaxStart(function() {

});

$(document).ajaxComplete(function() {

});
