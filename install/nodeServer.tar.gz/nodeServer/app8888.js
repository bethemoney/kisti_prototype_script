var express = require('express');
var path = require('path');
//var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');
var search = require('./routes/search');
var news =require('./routes/news');

var app = express();
app.set('view engine', 'jade');
app.set("view options", {layout: false});

app.use(express.static(__dirname+'/views'));

app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

app.use('/', routes);
app.use('/search', search);
app.use('/index',routes);
app.use('/news',news);

app.listen(8888,function (req,res) {
    console.log("nodeServer is on port 8888");
});
module.exports = app;
