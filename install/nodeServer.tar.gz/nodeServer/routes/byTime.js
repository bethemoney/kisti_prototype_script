var express = require('express');
var router = express.Router();
var spawn = require('child_process').spawnSync, child;
var async = require("async");

/* GET users listing. */

router.post('/', function(req, res, next) {

  var javaCommandPaperTimeAnalysis=spawn('java',['-jar','/home/hadoop/vectors/TimeAnalysis_0.5.jar', req.body.word, req.body.groupName,"paper"]);
  var javaCommandPatentTimeAnalysis=spawn('java',['-jar','/home/hadoop/vectors/TimeAnalysis_0.5.jar', req.body.word, req.body.groupName,"patent"]);
  var javaCommandReportTimeAnalysis=spawn('java',['-jar','/home/hadoop/vectors/TimeAnalysis_0.5.jar', req.body.word, req.body.groupName,"report"]);

  var javaCommandStepAnalysis=spawn('java',['-jar','/home/hadoop/vectors/StepAnalysis_0.7.jar',req.body.word,req.body.groupName]);


  var paperData=eval(javaCommandPaperTimeAnalysis.stdout.toString());
  var patentData=eval(javaCommandPatentTimeAnalysis.stdout.toString());
  var reportData=eval(javaCommandReportTimeAnalysis.stdout.toString());
  var stepData=eval(javaCommandStepAnalysis.stdout.toString());

  console.log(javaCommandReportTimeAnalysis.stderr.toString());
  console.log(reportData);

  var returnData={
      paperData:paperData,
      patentData:patentData,
      reportData:reportData,
      stepData:stepData
  }
  res.send(returnData);
});

module.exports = router;
