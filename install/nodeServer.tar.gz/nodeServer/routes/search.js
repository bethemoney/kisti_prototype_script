var express = require('express');
var router = express.Router();
var spawn = require('child_process').spawnSync,
  child;
var async = require("async");
var PATHs= require("./env.js");
/* GET users listing. */
router.post / ('/byTime', function(req, res, next) {
  //var zzz=spawn('java',['-jar','/home/hadoop/vectors/TimeAnalysis_0.1.jar', req.body.word,req.body.groupName]);
  console.log("test");

  res.send("asd");
})
router.post('/', function(req, res, next) {
  //console.log("reqData"+req.body.word);
  //requset data -> 단어와 단어가 포함된 문서번호
  var json = {
      word: req.body.word
    }
    //res.send(json);
  console.log(req.body.docIndex);
//  var commands = '/usr/bin/java -jar ~/vectors/word2ver ' + req.body.word;

  var javaCommandAll = spawn('java', ['-jar', PATHs.JAR_PATH+'/word2vec_0.5.jar', req.body.word, PATHs.DATA_PATH + req.body.groupName + '_all.txt']);
 // var javaCommandGetCluster = spawn('java', ['-jar',PATHs.JAR_PATH+'/Clustering_0.5.jar', req.body.word, PATHs.DATA_PATH + req.body.groupName + '_all.txt', 3]);
  var javaCommandGetCluster = spawn('java', ['-jar',PATHs.JAR_PATH+'/Clustering_0.7.jar', req.body.word, PATHs.DATA_PATH + req.body.groupName + '_all.txt']);
  var javaCommandPaperTimeAnalysis = spawn('java', ['-jar',  PATHs.JAR_PATH+'/TimeAnalysis_0.7.jar', req.body.word, req.body.groupName, "paper",PATHs.DATA_PATH,PATHs.JAR_PATH]);
  var javaCommandPatentTimeAnalysis = spawn('java', ['-jar', PATHs.JAR_PATH+'/TimeAnalysis_0.7.jar', req.body.word, req.body.groupName, "patent",PATHs.DATA_PATH,PATHs.JAR_PATH]);
  var javaCommandReportTimeAnalysis = spawn('java', ['-jar', PATHs.JAR_PATH+'/TimeAnalysis_0.7.jar', req.body.word, req.body.groupName, "report",PATHs.DATA_PATH,PATHs.JAR_PATH]);

  var javaCommandStepAnalysis = spawn('java', ['-jar',PATHs.JAR_PATH+'/StepAnalysis_0.7.jar', req.body.word, req.body.groupName,PATHs.DATA_PATH, PATHs.JAR_PATH]);


  var paperData = eval(javaCommandPaperTimeAnalysis.stdout.toString());
console.log(paperData);
  var patentData = eval(javaCommandPatentTimeAnalysis.stdout.toString());
  var reportData = eval(javaCommandReportTimeAnalysis.stdout.toString());
  var stepData = eval(javaCommandStepAnalysis.stdout.toString());


  var allData = eval(javaCommandAll.stdout.toString());
  var dataCluster = eval(javaCommandGetCluster.stdout.toString());


  var returnData = {
    resData: allData,
    //resDataIndexD : dataIndexD,
    resDataCluster: dataCluster,
    resPaperData: paperData,
    resPatentData: patentData,
    resReportData: reportData,
    resStepData: stepData
  }
  res.send(returnData);
});

module.exports = router;
