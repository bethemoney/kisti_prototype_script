var express = require('express');
var router = express.Router();
var spawn = require('child_process').spawnSync, child;
var async = require("async");

/* GET home page. */
router.get('/', function(req, res, next) {
  res.sendFile(app.get('views')+'/index.html');
 
});

module.exports = router;
