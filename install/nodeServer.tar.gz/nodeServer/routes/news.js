var express = require('express');
var router = express.Router();
var spawn = require('child_process').spawnSync, child;
var async = require("async");
var PATHs = require("./env.js");
var filesystem = require("fs");

/* GET users listing. */

router.post('/', function(req, res, next) {

  results=_getAllFilesFromFolder(__dirname+"/refinednews");
  /*var javaCommandNewsData=spawn('java',['-jar',PATHs.JAR_PATH+'/News_Data_0.1.jar', "방법", PATHs.DATA_PATH+"/news/result-cvb-05.txt",
                                                                                                 PATHs.DATA_PATH+"/news/result-cvb-06.txt",
        	                                                                                 PATHs.DATA_PATH+"/news/result-cvb-07.txt",
												 PATHs.DATA_PATH+"/news/result-cvb-08.txt",
  	                                                                                         PATHs.DATA_PATH+"/news/result-cvb-09.txt"]);
  var newsData=eval(javaCommandNewsData.stdout.toString());*/
  //console.log(results);
  results=_getNewestNews(results);
  var newestNewsData=[];
  var newsLength=0;
  if(results.length>=5){
    newsLength=5;
  }else{
	newsLength=results.length;
  }
  for (i=0;i<newsLength;i++){
	var contents = filesystem.readFileSync(__dirname+"/refinednews/"+results[i]);
	var jsonContent = JSON.parse(contents)
	console.log(jsonContent);
	newestNewsData.push(jsonContent);
  }
  var returnData={
      newsData:newestNewsData
  }
   res.send(returnData);

});

var _getNewestNews = function(results){

     var numbers=0;
     results.reverse();
	 console.log(results);
	 return results;
}

var _getAllFilesFromFolder = function(dir) {
	 var results = [];
	 filesystem.readdirSync(dir).forEach(function(file) {
	  path = dir+'/'+file;
	  var stat = filesystem.statSync(path);

	  if(stat&&stat.isFile()){
		results.push(file);
	  }
  });

  return results;
};


module.exports = router;
