var DATA_PATH="/home/eclab/shell_test/vector//";
var JAR_PATH="/home/eclab/shell_test/jars//";
var PATHs = {
	DATA_PATH:DATA_PATH,
	JAR_PATH:JAR_PATH
}
module.exports = PATHs;

